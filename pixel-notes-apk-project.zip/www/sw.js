const C='pxnotes-v2',A=['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png', './fonts/vazirmatn-arabic-400-normal.woff2', './fonts/vazirmatn-arabic-700-normal.woff2', './fonts/vazirmatn-latin-400-normal.woff2', './fonts/vazirmatn-latin-700-normal.woff2', './fonts/press-start-2p-latin-400-normal.woff2'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(A))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x))))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).catch(()=>caches.match('./index.html'))))});
